-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-09-2025 a las 18:53:25
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `veterinaria`
--
CREATE DATABASE IF NOT EXISTS `veterinaria` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `veterinaria`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL,
  `dni` int(11) DEFAULT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `telefono` bigint(20) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `contactoAlternativo` bigint(20) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`idCliente`, `dni`, `nombre`, `apellido`, `telefono`, `direccion`, `contactoAlternativo`, `activo`) VALUES
(1, 40123456, 'Martina', 'Gómez', 2664123456, 'Av. Libertad 123, San Luis', 2664987654, 1),
(2, 38987456, 'Lucas', 'Pereyra', 2664765432, 'Belgrano 456, La Punta', 2664234567, 1),
(3, 37234567, 'Julieta', 'Ramírez', 2664987123, 'San Martín 789, Villa Mercedes', 2664554321, 0),
(4, 42111222, 'Matías', 'Fernández', 2664345678, 'Mitre 321, Juana Koslay', 2664765123, 1),
(5, 35456789, 'Valentina', 'Sosa', 2664678901, 'Colón 654, San Luis', 2664223344, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascota`
--

CREATE TABLE `mascota` (
  `idMascota` int(11) NOT NULL,
  `alias` varchar(30) NOT NULL,
  `sexo` varchar(30) NOT NULL,
  `especie` varchar(30) NOT NULL,
  `raza` varchar(30) NOT NULL,
  `colorPelo` varchar(50) DEFAULT NULL,
  `fechaNac` date NOT NULL,
  `idCliente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mascota`
--

INSERT INTO `mascota` (`idMascota`, `alias`, `sexo`, `especie`, `raza`, `colorPelo`, `fechaNac`, `idCliente`) VALUES
(1, 'Luna', 'Hembra', 'canino', 'Caniche', 'Blanco', '2020-05-14', 1),
(2, 'Simba', 'Macho', 'Gato', 'Siames', 'Beige con marrón', '2021-09-30', 2),
(3, 'Rocky', 'Macho', 'canino', 'Labrador', 'Marrón claro', '2019-12-01', 3),
(4, 'Mora', 'Hembra', 'Gato', 'Persa', 'Gris', '2022-02-20', 4),
(5, 'Toby', 'Macho', 'canino', 'Bulldog Francés', 'Negro y blanco', '2021-07-11', 5),
(6, 'Nina', 'Hembra', 'Conejo', 'Mini Lop', 'Blanco y gris', '2023-03-05', 1),
(7, 'Max', 'Macho', 'canino', 'Ovejero Alemán', 'Negro y marrón', '2018-08-22', 2),
(8, 'Olivia', 'Hembra', 'Gato', 'Común europeo', 'Naranja', '2020-10-10', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tratamiento`
--

CREATE TABLE `tratamiento` (
  `idTratamiento` int(11) NOT NULL,
  `descripcion` varchar(70) NOT NULL,
  `medicamento` varchar(50) NOT NULL,
  `importe` double NOT NULL,
  `tipoTratamiento` varchar(30) NOT NULL,
  `activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tratamiento`
--

INSERT INTO `tratamiento` (`idTratamiento`, `descripcion`, `medicamento`, `importe`, `tipoTratamiento`, `activo`) VALUES
(1, 'Vacunación antirrábica anual', 'Vacuna Antirrábica', 3500, 'Vacunación', 1),
(2, 'Desparasitación interna', 'Albendazol', 2200.5, 'Desparasitación', 1),
(3, 'Desparasitación externa contra pulgas', 'Frontline', 2800, 'Desparasitación', 1),
(4, 'Control de infección cutánea', 'Cefalexina', 4100.75, 'Antibiótico', 1),
(5, 'Tratamiento dolor articular', 'Carprofeno', 5200, 'Analgésico', 1),
(6, 'Tratamiento de otitis', 'Otovet', 3900, 'Antibiótico', 1),
(7, 'Vacunación sextuple en cachorro', 'Vacuna Puppy DP', 4800, 'Vacunación', 1),
(8, 'Corte y limpieza dental', 'Anestesia + Limpieza', 8600, 'Odontología', 1),
(9, 'Tratamiento para parásitos intestinales', 'Ivermectina', 2500, 'Desparasitación', 0),
(10, 'Cicatrización postquirúrgica', 'Cicatrizante + Antiinflamatorio', 3000, 'Postoperatorio', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visita`
--

CREATE TABLE `visita` (
  `idVisita` int(11) NOT NULL,
  `fechaVisita` date NOT NULL,
  `detalle` varchar(50) NOT NULL,
  `peso` double NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `idMascota` int(11) DEFAULT NULL,
  `idTratamiento` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `visita`
--

INSERT INTO `visita` (`idVisita`, `fechaVisita`, `detalle`, `peso`, `activo`, `idMascota`, `idTratamiento`) VALUES
(1, '2024-05-10', 'Vacunación anual contra rabia', 5.2, 1, 1, 1),
(2, '2024-06-02', 'Desparasitación interna', 3.8, 1, 2, 2),
(3, '2024-06-15', 'Control general + desparasitación externa', 28.4, 1, 3, 3),
(4, '2024-07-01', 'Otitis en oído derecho', 4.5, 1, 4, 6),
(5, '2024-07-20', 'Vacunación sextuple', 12.3, 1, 5, 7),
(6, '2024-08-05', 'Limpieza dental por sarro', 2.1, 1, 6, 8),
(7, '2024-08-15', 'Dolor articular leve', 35.7, 1, 7, 5),
(8, '2024-09-03', 'Infección cutánea en pata trasera', 3.9, 1, 8, 4),
(9, '2024-10-11', 'Refuerzo desparasitación intestinal', 5.4, 0, 1, 9),
(10, '2024-11-25', 'Control postoperatorio', 29, 1, 3, 10);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`),
  ADD UNIQUE KEY `dni` (`dni`);

--
-- Indices de la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD PRIMARY KEY (`idMascota`),
  ADD KEY `FK_id_dueño` (`idCliente`);

--
-- Indices de la tabla `tratamiento`
--
ALTER TABLE `tratamiento`
  ADD PRIMARY KEY (`idTratamiento`);

--
-- Indices de la tabla `visita`
--
ALTER TABLE `visita`
  ADD PRIMARY KEY (`idVisita`),
  ADD KEY `FK_visita_idmascota` (`idMascota`),
  ADD KEY `FK_visita_tratamiento` (`idTratamiento`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `mascota`
--
ALTER TABLE `mascota`
  MODIFY `idMascota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `tratamiento`
--
ALTER TABLE `tratamiento`
  MODIFY `idTratamiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `visita`
--
ALTER TABLE `visita`
  MODIFY `idVisita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD CONSTRAINT `FK_id_dueño` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`);

--
-- Filtros para la tabla `visita`
--
ALTER TABLE `visita`
  ADD CONSTRAINT `FK_visita_idmascota` FOREIGN KEY (`idMascota`) REFERENCES `mascota` (`idMascota`),
  ADD CONSTRAINT `FK_visita_tratamiento` FOREIGN KEY (`idTratamiento`) REFERENCES `tratamiento` (`idTratamiento`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
